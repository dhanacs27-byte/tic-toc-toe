package com.game.tictactoe;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Board board = new Board();
        boolean gameOn = true;

        System.out.println("🎮 Welcome to Java Tic-Tac-Toe!");
        board.printBoard();

        while (gameOn) {
            System.out.println("Player " + board.getCurrentPlayer() + ", enter row and column (0-2): ");
            int row = scanner.nextInt();
            int col = scanner.nextInt();

            if (!board.makeMove(row, col)) {
                System.out.println("❌ Invalid move! Try again.");
                continue;
            }

            board.printBoard();

            if (board.checkWin()) {
                System.out.println("🏆 Player " + board.getCurrentPlayer() + " wins!");
                gameOn = false;
            } else if (board.isDraw()) {
                System.out.println("🤝 It's a draw!");
                gameOn = false;
            } else {
                board.switchPlayer();
            }
        }

        System.out.println("Game Over. Thanks for playing!");
        scanner.close();
    }
}
