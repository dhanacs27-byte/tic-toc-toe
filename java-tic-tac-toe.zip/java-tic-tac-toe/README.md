# 🎮 Java Tic-Tac-Toe (Console Version)

A simple **Tic-Tac-Toe game** built in Java for two players.  
Perfect for **college submission** or **GitHub demo project**.

## 🧩 Features
- Console-based two-player game
- Input validation
- Win, draw detection
- Clean and commented Java code

## 🗂️ Project Structure
```text
java-tic-tac-toe/
 ├── src/
 │   └── com/game/tictactoe/
 │       ├── Main.java
 │       └── Board.java
 ├── README.md
 └── .gitignore
```

## ▶️ How to Run

### 1. Compile
```bash
cd src
javac com/game/tictactoe/*.java
```

### 2. Run
```bash
java com.game.tictactoe.Main
```

## 💡 Example Gameplay
```
🎮 Welcome to Java Tic-Tac-Toe!
-------------
| - | - | - | 
| - | - | - | 
| - | - | - | 
-------------
Player X, enter row and column (0-2):
```

## 🏆 Author
You 😎 (CSE Student)
